package com.example.karkapazhagu;

public class Constants {

    public static final String STORAGE_PATH_UPLOADS = "extra activity/";
    public static final String DATABASE_PATH_UPLOADS = "extra activity";
}
